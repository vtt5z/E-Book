package com.folioreader.ui.base;

/**
 * @author gautam chibde on 12/6/17.
 */

public interface HtmlTaskCallback extends BaseMvpView {
    void onReceiveHtml(String html);
}
