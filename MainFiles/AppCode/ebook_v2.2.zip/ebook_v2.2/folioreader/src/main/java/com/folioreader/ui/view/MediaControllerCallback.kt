package com.folioreader.ui.view

/**
 * Created by gautam on 9/5/18.
 */
interface MediaControllerCallback {
    fun play()
    fun pause()
}