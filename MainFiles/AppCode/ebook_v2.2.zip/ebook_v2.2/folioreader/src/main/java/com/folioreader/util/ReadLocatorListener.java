package com.folioreader.util;

import com.folioreader.model.locators.ReadLocator;

/**
 * Created by Hrishikesh Kadam on 17/04/2018.
 */
public interface ReadLocatorListener {

    void saveReadLocator(ReadLocator readLocator);
}
