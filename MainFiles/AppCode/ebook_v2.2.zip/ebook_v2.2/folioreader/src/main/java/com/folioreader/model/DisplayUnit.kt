package com.folioreader.model

enum class DisplayUnit {
    PX,
    DP,
    CSS_PX
}