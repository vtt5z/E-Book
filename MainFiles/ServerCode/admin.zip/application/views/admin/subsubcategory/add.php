<?php $this->load->view('admin/comman/header');?>

<div class="clearfix"></div>

<div class="content-wrapper">
  <div class="container-fluid">

    <div class="row pt-2 pb-2">
      <div class="col p-md-0">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/dashboard">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/subsubcategory">Sub category</a></li>
          <li class="breadcrumb-item active"><a href="javascript:void(0)">Add Sub category</a></li>
        </ol>
      </div>
    </div>
<!-- row -->

<div class="container-fluid">
  <div class="row">
     <div class="col-lg-12">
        <div class="card">
           <div class="card-body">
              <div class="card-title">Add Sub category</div>
              <hr>
              <form id="subsubcategory_form"  enctype="multipart/form-data">
                <div class="form-group">
                  <label for="input-1"> Category </label>
                  <select name="category_id" id="category_id"  class="form-control col-8">
                    <option value="">Select Category</option>
                    <?php foreach ($category as $key => $value) {?>
                     <option  value="<?php echo $value->id;?>"> <?php echo $value->name;?> </option>       
                    <?php } ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="input-2">Sub Category</label>
                  <!-- DropDown -->
                  <select name="sub_category_id" id='sub_category_id' class="form-control col-8">
                    
                  </select>
                </div>
                <div class="form-group">
                  <label for="input-1"> Name</label>
                  <input type="text" name="name" class="form-control col-8" id="name" placeholder="Enter Your subsubcategory Name">
                </div>
                <div class="form-group">
                    <label for="input-2">Image</label>
                    <input type="file" name="image" class="form-control col-8" id="input-2" onchange="readURL(this,'showImage')" >
                    <p class="noteMsg">Note: Image Size must be lessthan 2MB.Image Height and Width less than 1000px.</p>
                    <img id="showImage" src="<?php echo base_url().'assets/images/placeholder.png';?>" height="150" width="150" alt="your image" />
                </div>
                <div class="form-group">
                  <button type="button" onclick="savesubsubcategory()" class="btn btn-primary shadow-primary px-5">Save</button>
                </div>
            </form>
        </div>
    </div>
  </div>
</div>
</div>
</div>

<script type="text/javascript">

    $('#category_id').on('change',function(){
    var category_id = $(this).val();
    $.ajax({
      type: 'POST',
      url: '<?php echo base_url(); ?>admin/subcategory/getsubcategory',
      data: {'category_id':category_id},
      dataType: "json",
      success: function (resp) {

        if(resp.status == 200)
        {
          $('#sub_category_id').html('');

          $('#sub_category_id')
                   .append($("<option></option>")
                              .attr("value", '')
                              .text('Select Sub Category'));
          $.each(resp.result, function(i,e) {
             $('#sub_category_id')
                   .append($("<option></option>")
                              .attr("value", e.id)
                              .text(e.name));
          });


        }
      },
      error: function (XMLHttpRequest, textStatus, errorThrown) {
        $("#dvloader").hide();
        toastr.error(errorThrown.message, 'failed');
      }
    });
  });

  function savesubsubcategory(){
    var formData = new FormData($("#subsubcategory_form")[0]);
     displayLoader();
     $.ajax({
        type:'POST',
        url:'<?php echo base_url(); ?>admin/subsubcategory/save',
        data:formData,
        cache:false,
        contentType: false,
        processData: false,
        dataType:'json',
        success:function(resp){
          hideLoader();
          if(resp.status=='200'){
            document.getElementById("subsubcategory_form").reset();
            toastr.success(resp.message);
            window.location.replace('<?php echo base_url(); ?>admin/subsubcategory');
          }else{
            toastr.error(resp.message);
          }
        }
      });
    }
</script>

<?php $this->load->view('admin/comman/footerpage'); ?>