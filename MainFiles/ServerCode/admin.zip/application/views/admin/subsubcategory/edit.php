<?php $this->load->view('admin/comman/header'); ?>
 <div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">
           <div class="col p-md-0">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/dashboard">Sub category</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/subsubcategory">Sub category</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Update Sub category</a></li>
                </ol>
            </div>
        </div>
        <!-- row -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Update Sub category</h4>
                            <form id="edit_subsubcategory_form"  enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="input-1"> Category </label>
                                    <select name="category_id" id="category_id" class="form-control col-8">
                                        <option value="">Select Category</option>
                                        <?php foreach ($category as $key => $value) {?>
                                         <option <?php if($value->id == $subsubcategory->category_id){ echo "selected"; }?> value="<?php echo $value->id;?>"> <?php echo $value->name;?> </option>       
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="input-2">Sub Category</label>
                                    <!-- DropDown -->
                                    <select name="sub_category_id" id='sub_category_id' class="form-control col-8">
                                        <option value=""> Select Sub category</option>
                                        <?php foreach($subcategory as $row){ ?>
                                            <option <?php if( $row->id == $subsubcategory->sub_category_id){ echo 'selected';}?> value="<?php echo $row->id;?>"> <?php echo $row->name;?> </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="input-1"> Name </label>
                                    <input type="text" name="name" class="form-control col-8" id="name" placeholder="Enter Your subsubcategory Name" value="<?php echo $subsubcategory->name?>">
                                </div>
                                <input type="hidden" name="id" value="<?PHP echo $subsubcategory->id; ?>">

                                <div class="form-group">
                                    <label for="input-2"> Image </label>
                                    <input type="file" name="image" class="form-control col-8" id="image" onchange="readURL(this,'subsubcategoryDisImage')" >
                                    <input type="hidden" name="subsubcategoryimage" value="<?PHP echo $subsubcategory->image; ?>" >
                                     <p class="noteMsg">Note: Image Size must be lessthan 2MB.Image Height and Width less than 1000px.</p>
                                    <div class="imgageResponsive">
                                        <img id="subsubcategoryDisImage" src="<?php echo base_url().'assets/images/subsubcategory/'.$subsubcategory->image; ?>" height="auto;" width="150px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" onclick="updatesubsubcategory()" class="btn btn-primary shadow-primary px-5">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
    </div>
<script type="text/javascript">

    $('#category_id').on('change',function(){
        var category_id = $(this).val();
        $.ajax({
          type: 'POST',
          url: '<?php echo base_url(); ?>admin/subcategory/getsubcategory',
          data: {'category_id':category_id},
          dataType: "json",
          success: function (resp) {

            if(resp.status == 200)
            {
              $('#sub_category_id').html('');

              $('#sub_category_id')
                       .append($("<option></option>")
                                  .attr("value", '')
                                  .text('Select Sub Category'));
              $.each(resp.result, function(i,e) {
                 $('#sub_category_id')
                       .append($("<option></option>")
                                  .attr("value", e.id)
                                  .text(e.name));
              });


            }
          },
          error: function (XMLHttpRequest, textStatus, errorThrown) {
            $("#dvloader").hide();
            toastr.error(errorThrown.message, 'failed');
          }
        });
    });
    

    function updatesubsubcategory(){
        var subsubcategory_name=jQuery('input[name=name]').val();
        if(subsubcategory_name==''){
            toastr.error('Please enter subsubcategory name','failed');
            return false;
        }
        $("#dvloader").css('display','block');
        $("body").addClass('overlay');

        var formData = new FormData($("#edit_subsubcategory_form")[0]);
        $.ajax({
            type:'POST',
            url:'<?php echo base_url(); ?>admin/subsubcategory/update',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            dataType:'json',
            success:function(resp){
             if(resp.status=='200'){
                 $("#dvloader").css('display','none');
                $("body").removeClass('overlay');
                toastr.success(resp.message);
                window.location.replace('<?php echo base_url(); ?>admin/subsubcategory');
                }else{
                    toastr.error(resp.message);
                    $("#dvloader").hide();
                }
            }
        });
    }
</script>

<?php $this->load->view('admin/comman/footerpage');?>