<?php $this->load->view('admin/comman/header');?>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="clearfix"></div>
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Earning setting</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url() ?>admin/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Earning setting</li>
                </ol>
            </div>
            
        </div>
        <!-- End Breadcrumb-->
        
        <div class="row">
            <?php
            $setn = array();
            foreach ($settinglist as $set) {
                $setn[$set->key] = $set->value;
            }


            ?>
            <style type="text/css">
                .set_box{
                    padding: 35px;
                }
            </style>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">                       
                        <div class="tab-content">                            
                            <div class="">
                                <div class="form-group">
                                    <form id="earn_point-1"  enctype="multipart/form-data">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th width="50%"> Activity Name  </th>
                                                    <th> Point</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($earn_point as $row) { 

                                                 if($row->point_type == 2){
                                                    ?>
                                                    <tr>
                                                        <td><?php echo str_replace('_', ' ', ucfirst($row->key)); ?></td>
                                                        <td><input type="number" name="<?php echo $row->key; ?>" required class="form-control" id="<?php echo $row->key; ?>"  value="<?php echo $row->value; ?>"></td>
                                                    </tr>
                                                <?php } } ?>
                                            </tbody>
                                        </table>
                                        <br><br>
                                        <div class="">
                                            <button type="button" class="btn btn-primary shadow-primary px-5" onclick="earn_point1()"> Save</button>
                                        </div>
                                    </form>
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>
</div>
  <?php $this->load->view('admin/comman/footerpage');?>

<!-- <script src="<?php echo base_url(); ?>assets/js/bootstrap-input-spinner.js"></script> -->

<script type="text/javascript">
    
    function earn_point1()
    {
        $("#dvloader").show();
        var formData = new FormData($("#earn_point-1")[0]);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>admin/generalsetting/earn_point',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (resp) {
                hideLoader();
                toastr.success('Earnpoint Setting Saved.');
                window.location.replace('<?php echo base_url(); ?>admin/generalsetting');
            }
        });
    }
    
</script>
