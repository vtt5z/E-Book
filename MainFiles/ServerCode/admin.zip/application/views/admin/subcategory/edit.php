<?php $this->load->view('admin/comman/header'); ?>
 <div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">
           <div class="col p-md-0">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/dashboard">Sub category</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/subcategory">Sub category</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Update Sub category</a></li>
                </ol>
            </div>
        </div>
        <!-- row -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Update Sub category</h4>
                            <form id="edit_subcategory_form"  enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="input-1"> Category </label>
                                    <select name="category_id" class="form-control col-8">
                                        <option value="">Select Category</option>
                                        <?php foreach ($category as $key => $value) {?>
                                         <option <?php if($value->id == $subcategory->category_id){ echo "selected"; }?> value="<?php echo $value->id;?>"> <?php echo $value->name;?> </option>       
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="input-1"> Name </label>
                                    <input type="text" name="name" class="form-control col-8" id="name" placeholder="Enter Your subcategory Name" value="<?php echo $subcategory->name?>">
                                </div>
                                <input type="hidden" name="id" value="<?PHP echo $subcategory->id; ?>">

                                <div class="form-group">
                                    <label for="input-2"> Image </label>
                                    <input type="file" name="image" class="form-control col-8" id="image" onchange="readURL(this,'subcategoryDisImage')" >
                                    <input type="hidden" name="subcategoryimage" value="<?PHP echo $subcategory->image; ?>" >
                                     <p class="noteMsg">Note: Image Size must be lessthan 2MB.Image Height and Width less than 1000px.</p>
                                    <div class="imgageResponsive">
                                        <img id="subcategoryDisImage" src="<?php echo base_url().'assets/images/subcategory/'.$subcategory->image; ?>" height="auto;" width="150px;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="button" onclick="updatesubcategory()" class="btn btn-primary shadow-primary px-5">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
    </div>
<script type="text/javascript">
    function updatesubcategory(){
        var subcategory_name=jQuery('input[name=name]').val();
        if(subcategory_name==''){
            toastr.error('Please enter subcategory name','failed');
            return false;
        }
        $("#dvloader").css('display','block');
        $("body").addClass('overlay');

        var formData = new FormData($("#edit_subcategory_form")[0]);
        $.ajax({
            type:'POST',
            url:'<?php echo base_url(); ?>admin/subcategory/update',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            dataType:'json',
            success:function(resp){
             if(resp.status=='200'){
                 $("#dvloader").css('display','none');
                $("body").removeClass('overlay');
                toastr.success(resp.message);
                window.location.replace('<?php echo base_url(); ?>admin/subcategory');
                }else{
                    toastr.error(resp.message);
                    $("#dvloader").hide();
                }
            }
        });
    }
</script>

<?php
   $this->load->view('admin/comman/footerpage');
  ?>