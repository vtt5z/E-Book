<?php $this->load->view('admin/comman/header');?>

<div class="clearfix"></div>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Payment Option -->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Payment Option List</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/paymentoption">Payment Option</a></li>
                    <li class="breadcrumb-item active" aria-current="page">List</li>
                </ol>
            </div>
        </div>
        <!-- End Payment Option -->

        <div class="">
            <div class="card">
                <div class="card-header"><i class="fa fa-table"></i> Payment Option Record</div>
                <div class="card-body">
                    <div class="">
                        <table id="paymentoption-datatable" class="table-sm table-striped table-bordered" width="100%">
                            <thead class="badge-secondary">
                                <tr>
                                    <th> Name </th>
                                    <th> Status </th>
                                    <th> Payment Environment </th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- End Row-->

    <?php $this->load->view('admin/comman/footerpage');?>

    <script>
    $(document).ready(function() {
        var dataTable = $('#paymentoption-datatable').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],
            "ajax": {
                url: "<?php echo base_url() . 'admin/paymentoption/fetch_data'; ?>",
                type: "POST"
            },
            "columnDefs":
            [
                {
                "orderable": false,
                }, 
            ],
        });
    });
    </script>