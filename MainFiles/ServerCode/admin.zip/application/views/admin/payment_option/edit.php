<?php $this->load->view('admin/comman/header');?>
<div class="clearfix"></div>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Payment Option Edit</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/paymentoption">Payment Option</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit</li>
                </ol>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <?php // print_r($package);?>
        <div class="row">
            <div class="col-lg-12 mx-auto">
                <div class="card">
                    <div class="card-body">
                        <form id="edit_paymentoption_form" enctype="multipart/form-data">
                            <div class="form-group  col-lg-8">
                                <label for="input-1"> Name</label>
                                <p><b><?PHP echo $payment_option->name; ?></b></p>
                            </div>

                            <div class="form-group  col-lg-8">
                                <label for="input-1"> Status </label>
                                <select   name="visibility" class="form-control"> 
                                    <option value="" > Select Visibility</option>
                                    <option value="1" <?php if($payment_option->visibility == 1){ echo "selected"; }?>> Active </option>
                                    <option value="0" <?php if($payment_option->visibility == 0){ echo "selected"; }?>> In Active</option>
                                </select>
                            </div>

                            <div class="form-group  col-lg-8">
                                <label for="input-1"> Payment Environment </label>
                                <select   name="is_live" class="form-control"> 
                                    <option value="" > Select Visibility</option>
                                    <option value="1" <?php if($payment_option->is_live == 1){ echo "selected"; }?>> Live </option>
                                    <option value="0" <?php if($payment_option->is_live == 0){ echo "selected"; }?>> Sandbox </option>
                                </select>
                            </div>

                        <?php if($payment_option->name != 'Razorpay' && $payment_option->name != 'InApp Purchage'){?>

                            <?php 
                                if($payment_option->name == 'Paypal'){
                                    // Live key 1
                                    $live_key_1 = 'Live PayPal Client ID';
                                    $test_key_1 = 'Test PayPal Client ID';
                                }

                                if($payment_option->name == 'PayTm'){
                                    // Live key 1
                                    $live_key_1 = 'Live Merchant ID';
                                    $live_key_2 = 'Live Merchant Key';

                                    $test_key_1 = 'Test Merchant ID';
                                    $test_key_2 = 'Test Merchant Key';
                                }

                                if($payment_option->name == 'PayUMoney'){
                                    // Live key 1
                                    $live_key_1 = 'Live Merchant ID';
                                    $live_key_2 = 'Live Merchant Key';
                                    $live_key_3 = 'Live Merchant Salt Key';

                                    $test_key_1 = 'Test Merchant ID';
                                    $test_key_2 = 'Test Merchant Key';
                                    $test_key_3 = 'Test Merchant Salt Key';
                                }


                                if($payment_option->name == 'FlutterWave'){
                                    // Live key 1
                                    $live_key_1 = 'Live Public ID';
                                    $live_key_2 = 'Live Encryption Key';

                                    $test_key_1 = 'Test Public ID';
                                    $test_key_2 = 'Test Encryption Key';
                                }

                            ?>
                            
                            <?php if(isset($live_key_1)){?>
                                <div class="form-group col-lg-8">
                                    <label for="input-1"><?php echo $live_key_1;?></label>
                                    <input type="text" name="live_key_1" value="<?PHP echo $payment_option->live_key_1; ?>" class="form-control" id="live_key_1">
                                </div>
                            <?php } ?>

                            <?php if(isset($live_key_2)){?>
                                <div class="form-group  col-lg-8">
                                    <label for="input-1"><?php echo $live_key_2;?></label>
                                    <input type="text" name="live_key_2"  value="<?PHP echo $payment_option->live_key_2; ?>" class="form-control" id="live_key_2">
                                </div>                           
                            <?php } ?>
                             <?php if(isset($live_key_3)){?>
                                <div class="form-group  col-lg-8">
                                    <label for="input-1"><?php echo $live_key_3;?></label>
                                    <input type="text" name="live_key_3"  value="<?PHP echo $payment_option->live_key_3; ?>" class="form-control" id="live_key_3">
                                </div>                           
                            <?php } ?>
                            <?php if(isset($test_key_1)){?>
                                <div class="form-group col-lg-8">
                                    <label for="input-1"><?php echo $test_key_1;?></label>
                                    <input type="text" name="test_key_1" value="<?PHP echo $payment_option->test_key_1; ?>" class="form-control" id="test_key_1">
                                </div>
                            <?php } ?>

                            <?php if(isset($test_key_2)){?>
                                <div class="form-group  col-lg-8">
                                    <label for="input-1"><?php echo $test_key_2;?></label>
                                    <input type="text" name="test_key_2"  value="<?PHP echo $payment_option->test_key_2; ?>" class="form-control" id="test_key_2">
                                </div>
                            <?php } ?>
                            <?php if(isset($test_key_3)){?>
                                <div class="form-group  col-lg-8">
                                    <label for="input-1"><?php echo $test_key_3;?></label>
                                    <input type="text" name="test_key_3"  value="<?PHP echo $payment_option->test_key_3; ?>" class="form-control" id="test_key_3">
                                </div>
                            <?php } ?>
                        <?php } ?>

                            <input type="hidden" name="id" value="<?PHP echo $payment_option->id; ?>">
                            
                            <div class="form-group  col-lg-8">
                                <button type="button" onclick="updatepackage()" class="btn btn-primary shadow-primary px-5"> Update </button>
                                <a href="<?php echo base_url(); ?>admin/paymentoption" class="border-primary btn btn-default px-5 "> Cancel </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('admin/comman/footerpage');?>
<script type="text/javascript">
function updatepackage() {
    $("#dvloader").show();
    var formData = new FormData($("#edit_paymentoption_form")[0]);
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url(); ?>admin/paymentoption/update',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function(resp) {
            $("#dvloader").hide();
            if (resp.status == '200') {
                document.getElementById("edit_paymentoption_form").reset();
                toastr.success(resp.message);
                window.location.replace('<?php echo base_url(); ?>admin/paymentoption');
            } else {
                var obj = resp.message;
                $.each(obj, function(i, e) {
                    toastr.error(e);
                });
            }
        }
    });
}
</script>