<?php

$this->load->view('admin/comman/header');

?>



<div class="clearfix"></div>



<div class="content-wrapper">

    <div class="container-fluid">

        <!-- Breadcrumb-->

        <div class="row pt-2 pb-2">

            <div class="col-sm-9">

                <h4 class="page-title">Add Ads Banner</h4>

                <ol class="breadcrumb">

                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/dashboard">Dashboard</a></li>

                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/adsbanner">Ads Banner</a></li>

                    <li class="breadcrumb-item active" aria-current="page">Add</li>

                </ol>

            </div>

        </div>

        <!-- End Breadcrumb-->

        <div class="row">

            <div class="col-lg-12 mx-auto">

                <div class="card">

                    <div class="card-body">

                        <form id="add_ads_banner_form" enctype="multipart/form-data">

                            <div class="form-row mt-3">

                                <div class="col-sm-6 ">

                                    <label for="name"> Name </label>

                                    <input type="text" required value="" class="form-control" name="name" id="title">

                                </div>

                            </div>



                            <div class="form-row mt-3">

                                <div class="col-sm-6 ">

                                    <label for="name"> URL </label>

                                    <input type="text" value="" class="form-control" name="url" id="url"

                                        placeholder="Enter URL">

                                </div>

                            </div>

                            <div class="form-row mt-3">

                                <div class="col-sm-6 ">

                                    <label for="book_id">Book </label>

                                    <select name="book_id" id="book_id" required class="form-control">

                                        <option value="">Select Book</option>

                                        <?php foreach ($book as $book) {?>

                                        <option required value="<?php echo $book->id; ?>"><?php echo $book->title; ?>

                                        </option>

                                        <?php }?>

                                    </select>

                                </div>

                            </div>



                            <div class="form-row mt-3">

                                <div class="col-sm-6 ">

                                    <label for="input-1"> Banner </label>

                                    <input type="file" required class="form-control" name="image" id="image"

                                        onchange="readURL(this,'showImage')">

                                    <p class="noteMsg">Note: Image Size must be less than 2MB.Image Height and Width

                                        less than 1000px.</p>

                                    <img id="showImage"

                                        src="<?php echo base_url() . 'assets/images/placeholder.png'; ?>"

                                        height="100px;" width="250px;" alt="your image" />

                                </div>

                            </div>

                            <div class="form-row mt-3">

                                <div class="col-sm-6 ">

                                    <button type="button" onclick="saveads_banner()"

                                        class="btn btn-primary shadow-primary px-5">Save</button>

                                    <a href="<?php echo base_url(); ?>admin/adsbanner"

                                        class="border-primary btn btn-default px-5 ">Cancel

                                    </a>

                                </div>

                            </div>



                        </form>

                    </div>

                </div>





            </div>

        </div>

    </div>

</div>



<?php

$this->load->view('admin/comman/footerpage');

?>

<script type="text/javascript">

function saveads_banner() {



    displayLoader();

    var formData = new FormData($("#add_ads_banner_form")[0]);



    $.ajax({

        type: 'POST',

        url: '<?php echo base_url(); ?>admin/banner/save',

        data: formData,

        cache: false,

        contentType: false,

        processData: false,

        dataType: "json",

        success: function(resp) {

            get_responce_message(resp, 'add_ads_banner_form', 'banner');

        },

        error: function(XMLHttpRequest, textStatus, errorThrown) {

            hideLoader();

            toastr.error(errorThrown.msg, 'failed');

        }

    });

}

</script>