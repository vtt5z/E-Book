<?php 
    $this->load->view('admin/comman/header');
    $category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 0;
    $name = isset($_GET['name']) ? $_GET['name'] : '';
?>
<style type="text/css">
    .fa-toggle-on{
    color: green;
    font-size: 20px;
    }
    .fa-toggle-off{
        color: red;
        font-size: 20px;
    }   
</style>

<div class="content-wrapper">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="clearfix"></div>
                <section class="filter-section">
                    <div class="container-fluid">
                        <div class="filter-section-box">
                            <div class="row">
                                <div class="col-md-9">
                                  <h4 style="float: left;">Filter: |</h4>
                                  <div class="pull-left">
                                    <div class="manage-section-box">
                                      <form class="form-inline" style="padding: 0px 14px;">
                                        <input class="form-control mr-sm-6 category_search" value="<?php echo $name;?>" type="search" placeholder="Search..." aria-label="Search">
                                          <a href="#" id="search_category" ><img src="<?php echo base_url().'/assets/images/search-solid.svg'; ?>"></a>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-3 col-xs-12 p-3">
                                  <div style="float:right">
                                      <a class="btn btn-success" href="<?php echo base_url().'admin/category/add';?>"> Add </a>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="videos-section">
                    <div class="container-fluid">
                        <div class="videos-section-box">
                            <div class="row">
                                <?php 

                                if(count($category) > 0 ){
                                $i=1;foreach($category as $row){ ?>
                                    <div class="col-md-3">
                                        <div class="videos-section-main">
                                            <div class="video-img" style="border: 1px solid;border-radius: 15px;">
                                                <img src="<?php echo get_image_path($row['image'], 'category'); ?> ">
                                            </div>
                                            <div class="videos-section-head">
                                                <div class="pull-left bottom-view-left">
                                                    <p style="font-size: 14px;font-weight: bold;">
                                                        <?php 
                                                            if(strlen($row['name']) > 10)
                                                            {
                                                                echo substr($row['name'], 0,10). ' ...';
                                                            }
                                                            else
                                                            {
                                                                echo $row['name'];  
                                                            }
                                                        ?>
                                                    </p>
                                                 
                                                </div>
                                              
                                              
                                            </div>
                                            <div class="social">
                                                <div class="social-icon">
                                                    <a href="<?php echo base_url()?>admin/category/edit?id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-tooltip="Edit category" title="Edit category" class="social-icon-box" ><i class="fa fa-edit"></i></a>
                                                </div>
                                                <div class="social-icon">
                                                    <a href="javaScript:void(0)" data-toggle="tooltip" data-tooltip="Delete category" class="btn_delete_a social-icon-box" title="Delete category" onclick="delete_record('<?php echo $row['id']; ?>','category')"><i class="fa fa-trash"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php }
                                    }else{?>
                                    <div> <p> Record not found</p></div>
                                <?php } ?>
                            </div>

                            <div class="pull-right">
                                <?php 
                                    $pageno = $pagination['page']; 
                                    $total_pages = $pagination['total_pages']; 

                                    $start_number =$pageno;
                                    if($pageno > 1)
                                    {
                                        $start_number = $pageno - 1;
                                    } 

                                    if($total_pages == $pageno)
                                    {
                                        $end_number = $pageno;
                                    }
                                    else
                                    {
                                        $end_number = $pageno +1;
                                    }

                                    $base_url = base_url().'admin/category?page=';
                                    
                                ?>
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo  base_url();?>admin/category">First</a></li>
                                        <?php if($pageno <= 1){}else{ ?>
                                        <li class="page-item <?php if($pageno <= 1){ echo 'disabled'; } ?>">
                                            <a  class="page-link" href="<?php echo  $base_url.($pageno - 1);?>">Prev</a>
                                        </li>
                                        <?php } ?>
                                        <?php 
                                            for ($i = $start_number; $i <= $end_number; $i++)
                                            {
                                                $url = $base_url.$i;
                                        ?>
                                        <li class="page-item <?php if($pageno == $i){ echo 'active'; }?>"><a class="page-link" href="<?php echo $url; ?>" id="page[<?php echo $i;?>]" > <?php echo $i;?></a>
                                        </li>
                                        <?php } ?>

                                        <?php if($pageno >= $total_pages){ }else{?>
                                        <li class="page-item <?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                                            <a class="page-link" href="<?php echo  $base_url.($pageno + 1); ?>">Next</a>
                                        </li>
                                        <?php } ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo  $base_url.$total_pages; ?>">Last</a></li>
                                    </ul>
                                </nav>
                            </div>

                            <div class="pull-left">
                                <?php $totla_record = isset($pagination['totla_record']) ? $pagination['totla_record'] : 0; ?>

                                <?php
                                    if($pageno > 1 ){
                                        $current_show_no =  ($pageno - 1) * ($pagination['per_page']) ; 
                                        $end_show_no  =$pagination['per_page'] *$pageno ;
                                    }else
                                    {
                                        $current_show_no =  1 ;
                                        $end_show_no  =$pagination['per_page'] *$pageno ;
                                    }

                                    if($total_pages == $pageno)
                                    {   
                                        if($total_pages == 1)
                                        {
                                            $end_show_no = count($category);
                                        }else
                                        {
                                            $end_show_no = $current_show_no + count($category);
                                        }
                                    }
                                ?>
                                Showing <?php echo $current_show_no ; ?> to <?php echo $end_show_no ; ?> of <?php echo $totla_record; ?> entries
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('admin/comman/footerpage');?>

<script>
    $('#search_category').on('click', function(){
        var category_name = $('.category_search').val();   
        if(category_name){
            window.location.replace('<?php echo base_url(); ?>admin/category?name='+category_name);
        }else{
            window.location.replace('<?php echo base_url(); ?>admin/category');
        } 
    })

    $('#category_id').on('change', function(){
        var category_id = $(this).val();
        if(category_id > 0){
            window.location.replace('<?php echo base_url(); ?>admin/category?category_id='+category_id);
        }else{
            window.location.replace('<?php echo base_url(); ?>admin/category');
        }
    })

    $(document).ready(function() {
        $('#default-datatable').DataTable();
    });
 
  
</script>
