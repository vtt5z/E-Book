<?php $this->load->view('web/common/header');?>
<div class="road">
    <div class="container">
        <div class="row">
            <div class="col">
                <a href="<?php echo base_url()?>">Home</a><span>»</span><span>PROJECT DETAI</span>
            </div>
        </div>
    </div>
</div>
<!-- START SECTION PROJECTS SINGLE -->
<section class="service-details">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 project-info">
                <div class="row">
                    <div class="col-md-12 hover-effect">
                        <?php 
							$image_1 =  get_image_path($recently_work['image_1'], 'bg');
							$banner_image =  get_image_path($recently_work['banner_image'], 'bg');
						?>
                        <figure><img src="<?php echo $image_1;?>" alt=""></figure>
                        <div class="project-text">
                            <h3 class="mt-3">Design Planning</h3>
                            <p class="mb-4"><?php echo $recently_work['description'];?></p>
                            <h3 class="mt-4">Project Analysis</h3>
                            <img src="<?php echo $banner_image;?>" class="mb-3" alt="">
                            <p class="mb-4"><?php echo $recently_work['project_analysis'];?></p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- END SECTION PROJECTS SINGLE -->
<?php $this->load->view('web/common/footer');?>