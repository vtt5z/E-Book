<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Generalsetting extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $CI = & get_instance();
        $CI->load->library('session');
        frontendcheck();
    }

    public function index() {
        $data['earn_point'] = $this->CRUD_model->get('', 'earn_point');
       
        $getsettings = get_setting();
        $data['settinglist'] = $getsettings;
        $this->load->view("admin/settings/earning", $data);
    }

    public function general_settings() {
        $data['earnpoint_settings'] = $this->CRUD_model->get('', 'earnpoint_settings');

        $getsettings = get_settings();
        $data['settingslist'] = $getsettings;
        $this->load->view("admin/settings/earning", $data);
    }

    public function earn_point(){
        $data = $_POST;
        
        foreach ($data as $key => $value) {
            if ($value) {
                $array['value'] = $value;
                $result = $this->CRUD_model->updateById($key, 'key', $array, 'earn_point');
            }
        }
        return true;
    }
}
