<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller{

	public function __construct() {
		parent::__construct();
		$CI =& get_instance();
	}

	public function index(){

		if($this->session->userdata('id')) {
			redirect(base_url().'admin/dashboard');
		}else{
			// $data['settinglist'] = get_setting();
			// p($data);
			$this->load->view("admin/login/login");
		}
	}

	public function adminlogin(){
		$email= $this->input->post('email');
		$password= $this->input->post('password');
		$where='password="'.md5($password).'" and email="'.$email.'"';
		$result = $this->CRUD_model->getById($where,'tbl_author');
	
		if(isset($result->id)) {
			$this->session->set_userdata('email',$result->email);
			$this->session->set_userdata('id',$result->id);	
			$this->session->set_userdata('role_id',$result->role_id);	
			$this->session->set_userdata('name',$result->name);
			$this->session->set_userdata('image',$result->image);						
			
			$where_status = 'status=1'; 
			$currency = $this->CRUD_model->getById($where_status,'currency');
			
			if(isset($currency->code))
			{
				$this->session->set_userdata('currency_code',$currency->code);
				$this->session->set_userdata('currency_symbol',$currency->symbol);						
			}else
			{
				$this->session->set_userdata('currency_code','USD');
				$this->session->set_userdata('currency_symbol','$');						
			}

			if($result->role_id)
			{
				$result = array('status'=>200,'message'=>"Login successfully",'role_id'=>$result->role_id);
				echo json_encode($result);exit;
			}
			else
			{
				$result = array('status'=>200,'message'=>"Login successfully",'role_id'=>$result->role_id);
				echo json_encode($result);exit;
			}

		} else {
			$result = array('status'=>400,'message'=>"User name and password is incorrect");
			echo json_encode($result);exit;
		}
	}

	public function logout(){
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('id');
		$this->session->unset_userdata('name');
		redirect(base_url().'admin/login');
	}

}
