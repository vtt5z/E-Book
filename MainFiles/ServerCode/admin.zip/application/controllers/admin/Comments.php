<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comments extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$CI =& get_instance();
		frontendcheck();
	}

	// public function index(){
	//     $field = 'comment.*,book.title';
	// 	$joinid = 'book.id = comment.book_id';
	// 	$data['comments'] = $this->CRUD_model->get_join_allrecord('comment','book',$joinid,$field,'','desc');
	// 	$this->load->view("admin/comment/list",$data);
	// }
	public function index(){


		$table = 'comment';
		$data['order_by'] = 'DESC';
		$data['order_by_field'] = $table.'.id';

		// Join data
		$join_array = array(
						array('join' => 'book.id='.$table.'.book_id', 'table' => 'book'),
						array('join' => 'user.id='.$table.'.user_id', 'table' => 'user'),
					);


		$where_in = '';
		$data['field'] = 'comment.*,book.title,user.fullname';
		$data['table'] = $table;
		$data['where_in'] = $where_in;
		$data['joins'] = $join_array;

		$data['comments'] = $this->CRUD_model->get_join($data);
		


	 //    $field = 'comment.*,book.title','user.fullname';
		// $joinid = 'book.id = comment.book_id';
		// $joinid2 = 'user.id = comment.user_id';
		// $data['comments'] = $this->CRUD_model->get_two_join_allrecord('comment','book','user',$joinid,$joinid2,$field,'','desc');
		$this->load->view("admin/comment/list",$data);
	}	
	public function update(){
		$id = $_POST['id'];
		
		if($_POST['status'] == '1')
    	{
    		$status = '0';	
    	}
    	else
    	{
    		$status = '1';
    	}
    	$data = array( 'status' => $status);
		$res_id=$this->CRUD_model->update($id,'id',$data,'comment');
		
		if($res_id){
			$res=array('status'=>'200','msg'=>'Update status Sucessfully',
				'id'=>$id,'book_status'=>$status);
			echo json_encode($res);exit;
		}else{
			$res=array('status'=>'400','msg'=>'Please try again','book_status'=>$status);
			echo json_encode($res);exit;
		}
	}	
}